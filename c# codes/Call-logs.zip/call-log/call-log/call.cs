﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
namespace call_log
{
    class call
    {
        string s;
        ArrayList dt = new ArrayList();
        ArrayList ctime = new ArrayList();
        ArrayList etime = new ArrayList();

        public void makecall()
        {
            dt.Add(DateTime.Now.Date.ToString("dd/mm/yyyy"));

            ctime.Add(DateTime.Now.TimeOfDay);


        }

        public string callhistory()
        {
            etime.Add(DateTime.Now.TimeOfDay);
            
            for (int i = 0; i < dt.Count; i++)
            {   
                 string s1= ctime[i].ToString();
                string s2= etime[i].ToString();
                TimeSpan t1 = TimeSpan.Parse(s1);
                TimeSpan t2 = TimeSpan.Parse(s2);

                s = dt[i].ToString() + "\t" + ctime[i].ToString() + "\t\t" + etime[i].ToString() + "\t\t" + (t2 - t1).ToString(); ;
            }
            return s;



        }
    }
}
