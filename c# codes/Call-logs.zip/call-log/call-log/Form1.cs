﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace call_log
{
    public partial class Form1 : Form
    {
        call c = new call();
        public Form1()
        {
            InitializeComponent();
        }

       

        private void button1_Click(object sender, EventArgs e)
        {
            c.makecall();
            label5.Text = "Call on Progress";
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string s = c.callhistory();
            listBox1.Items.Add(s);
            label5.Text = "Call Ended";
            
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        
    }
}
