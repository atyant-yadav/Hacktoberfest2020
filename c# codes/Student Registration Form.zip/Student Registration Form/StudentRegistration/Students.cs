﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentRegistration
{
    class Students
    {
        int _regdNo;
        String _stdName;
        String _stdfName;
        String _stdAddress;
        String _stdCity;
        String _stdState;

        public int regdNo  //property
        {
            get { return _regdNo; } //get Method
            set { _regdNo = value; } //Set Method
        }
        public String stdName  //property
        {
            get { return _stdName; } //get Method
            set { _stdName = value; } //Set Method
        }
        public String stdfName  //property
        {
            get { return _stdfName; } //get Method
            set { _stdfName = value; } //Set Method
        }
        public String stdAddress  //property
        {
            get { return _stdAddress; } //get Method
            set { _stdAddress = value; } //Set Method
        }
        public String stdCity  //property
        {
            get { return _stdCity; } //get Method
            set { _stdCity = value; } //Set Method
        }
        public String stdState  //property
        {
            get { return _stdState; } //get Method
            set { _stdState = value; } //Set Method
        }

    }
}
