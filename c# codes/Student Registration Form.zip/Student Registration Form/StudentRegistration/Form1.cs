﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentRegistration
{
    public partial class Form1 : Form
    {
        Students[] a = new Students[10];
        int i = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            a[i] = new Students();
            a[i].regdNo = int.Parse(textBox1.Text);
            a[i].stdName = textBox2.Text;
            a[i].stdfName = textBox3.Text;
            a[i].stdAddress = textBox5.Text;
            a[i].stdCity = textBox4.Text;
            a[i].stdState = comboBox1.Text;
            

            listBox1.Items.Add(textBox1.Text);

            i = i + 1;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
